nama DataBase: info_surah
Framework    : CodeIgniter 4
Versi PHP    : 8.2.12
Versi MySQL  : 10.4.32-MariaDB - mariadb.org binary distribution

https://drive.google.com/file/d/1XHEqVUZ1rtx433hLBiB7kcnScQzPrC3z/view?usp=sharing