<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Pages::index');
$routes->get('/pages/surah', 'Pages::surah');
$routes->get('/pages/sunnah', 'Pages::sunnah');
$routes->get('/pages/rukun', 'Pages::rukun');

$routes->get('/SurahPages/an_nas', 'Surah::index');
$routes->get('/SurahPages/al_falaq', 'Surah::al_falaq');
$routes->get('/SurahPages/al_ikhlas', 'Surah::al_ikhlas');
$routes->get('/SurahPages/al_lahab', 'Surah::al_lahab');
$routes->get('/SurahPages/an_nasr', 'Surah::an_nasr');

$routes->get('/SunnahPages/makan', 'Sunnah::index');
$routes->get('/SunnahPages/tidur', 'Sunnah::tidur');
$routes->get('/SunnahPages/kamar_mandi', 'Sunnah::kamar_mandi');

$routes->get('/RukunPages/Islam', 'Rukun::index');
$routes->get('/RukunPages/Iman', 'Rukun::iman');