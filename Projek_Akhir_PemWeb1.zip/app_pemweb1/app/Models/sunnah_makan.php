<?php

namespace App\Models;

use CodeIgniter\Model;

class sunnah_makan extends Model
{
    protected $table = "sunnah_makan";

}