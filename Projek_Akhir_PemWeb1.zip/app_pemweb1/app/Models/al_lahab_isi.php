<?php

namespace App\Models;

use CodeIgniter\Model;

class al_lahab_isi extends Model
{
    protected $table = 'surah_lahab';
}