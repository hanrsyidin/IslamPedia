<?php

namespace App\Models;

use CodeIgniter\Model;

class judul_surahModel extends Model
{
    protected $table = "judul_surah";

}