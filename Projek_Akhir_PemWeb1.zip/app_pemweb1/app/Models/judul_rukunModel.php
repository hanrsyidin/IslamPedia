<?php

namespace App\Models;

use CodeIgniter\Model;

class judul_rukunModel extends Model
{
    protected $table = 'judul_rukun';
    protected $allowedFields = ['judul'];
}