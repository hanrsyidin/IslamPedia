<?php

namespace App\Models;

use CodeIgniter\Model;

class an_nasr_isi extends Model
{
    protected $table = 'surah_an_nasr';
}