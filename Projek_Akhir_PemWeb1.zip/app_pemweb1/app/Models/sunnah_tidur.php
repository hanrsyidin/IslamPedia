<?php

namespace App\Models;

use CodeIgniter\Model;

class sunnah_tidur extends Model
{
    protected $table = "sunnah_tidur";

}