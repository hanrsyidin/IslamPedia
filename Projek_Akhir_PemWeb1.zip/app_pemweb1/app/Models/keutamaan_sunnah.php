<?php

namespace App\Models;

use CodeIgniter\Model;

class keutamaan_sunnah extends Model
{
    protected $table = "keutamaan_sunnah";
}