<?php

namespace App\Models;

use CodeIgniter\Model;

class rukun_islam extends Model
{
    protected $table = 'rukun_islam';
}