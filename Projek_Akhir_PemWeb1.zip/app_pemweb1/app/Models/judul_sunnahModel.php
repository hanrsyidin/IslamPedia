<?php

namespace App\Models;

use CodeIgniter\Model;

class judul_sunnahModel extends Model
{
    protected $table = 'judul_sunnah';
    protected $allowedFields = ['judul'];
}