<?php

namespace App\Models;

use CodeIgniter\Model;

class kisah_surah extends Model
{
    protected $table = 'kisah_surah';
}