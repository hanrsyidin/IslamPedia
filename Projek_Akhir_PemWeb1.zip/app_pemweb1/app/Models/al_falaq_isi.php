<?php

namespace App\Models;

use CodeIgniter\Model;

class al_falaq_isi extends Model
{
    protected $table = 'surah_al_falaq';
}