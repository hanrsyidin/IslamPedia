<?php

namespace App\Models;

use CodeIgniter\Model;

class an_nas_isi extends Model
{
    protected $table = 'surah_an_nas';
}