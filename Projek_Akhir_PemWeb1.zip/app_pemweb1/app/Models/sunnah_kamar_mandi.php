<?php

namespace App\Models;

use CodeIgniter\Model;

class sunnah_kamar_mandi extends Model
{
    protected $table = "sunnah_kamar_mandi";

}