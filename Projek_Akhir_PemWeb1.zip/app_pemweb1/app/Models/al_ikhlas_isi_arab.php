<?php

namespace App\Models;

use CodeIgniter\Model;

class al_ikhlas_isi_arab extends Model
{
    protected $table = 'surah_al_ikhlas';
}