<?php

namespace App\Controllers;

class Rukun extends BaseController
{
    public function index()
    {
        $isi_islam = new \App\Models\rukun_islam();
        $isi = $isi_islam->findAll();
        
        $data = [
            "title" => "Rukun | Rukun Islam",
            "isi"=> $isi
    ]; 
        return view("/RukunPages/islam", $data);
    }

    public function iman()
    {
        $isi_iman = new \App\Models\rukun_iman();
        $isi = $isi_iman->findAll();

        $data = [
            "title" => "Rukun | Rukun Iman",
            "isi"=> $isi
    ];
        return view("/RukunPages/iman", $data);
    }
}
