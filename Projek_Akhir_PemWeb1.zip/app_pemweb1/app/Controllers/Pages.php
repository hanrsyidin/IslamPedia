<?php

namespace App\Controllers;


class pages extends BaseController
{
    public function index()
    {
        $data = [
            "title" => "Home | IslamPedia"
        ];
        return view("pages/home", $data);
    }

    public function surah()
    {
        $judul_surahModel = new \App\Models\judul_surahModel();
        $judul = $judul_surahModel ->findALL();

        // foreach ($judul->getResultArray() as $row) {
        //     d($row);
        // }
        
        $data = [
            "title" => "Surah | IslamPedia",
            "judul"=> $judul
        ];
        return view("pages/surah", $data);
    }

    public function sunnah()
    {
        $judul_rukunModel = new \App\Models\judul_sunnahModel();
        $judul = $judul_rukunModel ->findALL();

        $data = [
            "title" => "Sunnah | IslamPedia",
            "judul" => $judul
        ];
        return view("pages/sunnah", $data);
    }

    public function rukun()
    {
        $judul_rukunModel = new \App\Models\judul_rukunModel();
        $judul = $judul_rukunModel ->findALL();

        $data = [
            "title" => "Rukun | IslamPedia",
            "judul" => $judul
        ];
        return view("pages/rukun", $data);
    }
}