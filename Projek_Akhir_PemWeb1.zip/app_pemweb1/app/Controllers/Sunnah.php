<?php

namespace App\Controllers;

class sunnah extends BaseController
{
    public function index()
    {
        $isi_makan = new \App\Models\sunnah_makan();
        $isi = $isi_makan->findAll();

        $keutamaan_sunnah = new \App\Models\keutamaan_sunnah();
        $keutamaan = $keutamaan_sunnah->where('id', '1')->first();
        
        $data = [
        "title" => "Sunnah | Doa Makan",
        "isi"=> $isi,
        "keutamaan"=> $keutamaan
    ];
        return view("/SunnahPages/makan", $data);
    }

    public function tidur()
    {   
        $isi_tidur = new \App\Models\sunnah_tidur();
        $isi = $isi_tidur->findAll();

        $keutamaan_sunnah = new \App\Models\keutamaan_sunnah();
        $keutamaan = $keutamaan_sunnah->where('id', '2')->first();

        $data = [
        "title" => "Sunnah | Doa Tidur",
        "isi"=> $isi,
        "keutamaan"=> $keutamaan
    ];
        return view("/SunnahPages/tidur", $data);
    }

    public function kamar_mandi()
    {   
        $isi_kamar_mandi = new \App\Models\sunnah_kamar_mandi();
        $isi = $isi_kamar_mandi->findAll();

        $keutamaan_sunnah = new \App\Models\keutamaan_sunnah();
        $keutamaan = $keutamaan_sunnah->where('id', '3')->first();


        $data = [
        "title" => "Sunnah | Doa Kamar Mandi",
        "isi"=> $isi,
        "keutamaan"=> $keutamaan
    ];
        return view("/SunnahPages/kamar_mandi", $data);
    }
}
