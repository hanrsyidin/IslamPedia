<?php

namespace App\Controllers;


class Surah extends BaseController
{
    public function index()
    {
        $an_nas_isi = new \App\Models\an_nas_isi();
        $isi = $an_nas_isi ->findALL();

        $kisah_surah = new \App\Models\kisah_surah();
        $kisah = $kisah_surah->where('id', '2')->first();

        $data = [
            "title" => "Surah | An_nas",
            "isi" => $isi,
            "kisah" => $kisah['isi_kisah'] ?? ''
        ];
        return view("SurahPages/an_nas", $data);
    }

    public function al_falaq()
    {
        $al_falaq_isi = new \App\Models\al_falaq_isi();
        $isi = $al_falaq_isi ->findALL();

        $kisah_surah = new \App\Models\kisah_surah();
        $kisah = $kisah_surah->where('id', '3')->first();
        $data = [
            "title" => "Surah | Al_falaq",
            "isi" => $isi,
            "kisah" => $kisah['isi_kisah'] ?? ''
        ];
        return view("SurahPages/al_falaq", $data);
    }

    public function al_ikhlas()
    {
        $al_ikhlas_isi_arab = new \App\Models\al_ikhlas_isi_arab();
        $isi = $al_ikhlas_isi_arab ->findALL();

        $kisah_surah = new \App\Models\kisah_surah();
        $kisah = $kisah_surah->where('id', '1')->first();

        $data = [
            "title" => "Surah | Al_ikhlas",
            "isi" => $isi,
            "kisah" => $kisah['isi_kisah'] ?? ''
        ];
        return view("SurahPages/al_ikhlas", $data);
    }

    public function al_lahab()
    {
        $al_lahab_isi = new \App\Models\al_lahab_isi();
        $isi = $al_lahab_isi ->findALL();

        $kisah_surah = new \App\Models\kisah_surah();
        $kisah = $kisah_surah->where('id', '4')->first();

        $data = [
            "title" => "Surah | Al_lahab",
            "isi" => $isi,
            "kisah" => $kisah['isi_kisah'] ?? ''
        ];
        return view("SurahPages/al_lahab", $data);
    }

    public function an_nasr()
    {
        $an_nasr_isi = new \App\Models\an_nasr_isi();
        $isi = $an_nasr_isi ->findALL();

        $kisah_surah = new \App\Models\kisah_surah();
        $kisah = $kisah_surah->where('id', '5')->first();

        $data = [
            "title" => "Surah | An_nasr",
            "isi" => $isi,
            "kisah" => $kisah['isi_kisah'] ?? ''
        ];
        return view("SurahPages/an_nasr", $data);
    }
}