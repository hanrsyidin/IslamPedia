<?= $this->extend("layout/template") ?>
<?= $this->section("content") ?>
    <section class="containerSurah">
        <p style="font-size: x-large; display:flex; justify-content: center;">112. Al-Ikhlas (Mekah | 4 ayat)</p>
        <div style="display: flex; justify-content: center; margin-top: 5vh">
            <img src="<?= base_url('images/Home-Image.png'); ?>" alt="" style="width: 250px;">
        </div>
        <div style="display: flex; width: 100%; justify-content: space-between; gap: 1vw;">
            <div style="width: 50%;; margin-top: 5vh;">
                <h2 style="display: flex; justify-content: center;">Kisah</h2>
                <p style="text-align: justify; font-size:larger;"><?= $kisah ?></p>
            </div>
            <div style="width: 50%;">
                <?php foreach ($isi as $i) : ?>
                    <p style="font-size: xx-large; display: flex; justify-content:end; margin-top: 5vh;"><?= esc($i['isi_arab']) ?></p>
                    <p style="font-size: larger; opacity:calc(0.5); display: flex; justify-content:end;"><?= esc($i['isi_latin']) ?></p>
                    <p style="font-size: larger; opacity:calc(0.5); display: flex; justify-content:end; text-align: end"><?= esc($i['isi_indonesia']) ?></p>
                <?php endforeach ?>
            </div>
        </div>
    </section>
<?= $this->endSection() ?>