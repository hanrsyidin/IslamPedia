<?= $this->extend("layout/template") ?>
<?= $this->section("content") ?>
    <div class="containerBody-homePage">
        <section class="kontenBody1-homePage animated-left">
            <div class="bingkaiKontenBody1-homePage">
            <p style="font-size: xx-large">Selamat Datang di <span id="typing-text"></span></p>
                <p style=" color: rgba(0, 0, 0, 0.75); font-size: x-large; width: 36.39vw; height: 60.18vh; margin-top: 1.14vh; text-align: justify;">IslamPedia adalah sebuah platform edukasi digital yang menyajikan informasi lengkap tentang ajaran Islam, mencakup penjelasan surah Al-Quran beserta terjemahan, tulisan latin dan kisah turunnya (asbabun nuzul), sunnah-sunnah Rasulullah SAW, serta rukun-rukun Islam. Website ini dirancang untuk menjadi sumber referensi Islami yang mudah diakses, disukai oleh anak-anak hingga lansia, serta membantu umat Islam maupun siapa saja yang ingin mempelajari dasar-dasar dan nilai-nilai Islam secara mendalam. Dengan tampilan yang user-friendly dan konten terpercaya, IslamPedia memperkuat pemahaman umat Islam dan mendukung pembelajaran yang berkelanjutan.</p>
                <div class="bingkaiMenusDalamKontenBody1">
                    <a href="/pages/surah" class="menusDalamKontenBody1">Surah</a>
                    <a href="/pages/sunnah" class="menusDalamKontenBody1">Sunnah</a>
                    <a href="/pages/rukun" class="menusDalamKontenBody1">Rukun</a>
                </div>
            </div>
        </section>
        <section class="kontenBody2-homePage animated-right">
            <div class="bingkaiKontenBody2-homePage">
                <img src="<?= base_url('images/Home-Image.png'); ?>" alt="" style="width: 530px;">
            </div>
        </section>
    </div>
<?= $this->endSection() ?>