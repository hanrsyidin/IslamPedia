<?= $this->extend("layout/template") ?>
<?= $this->section("content") ?>
    <div class="containerBody-surahPage">
        <section class="kontenSurah1 pointer">
            <div class="bingkaiKontenSurah1">
                <?php foreach ($judul as $j) : ?>
                <a href="<?= $j['baseURL'] ?>" class="judulKontenSurah1">
                    <p style="font-size: larger; margin-left: auto; margin-right: auto; padding-left: 10px;"><?= esc($j['judul']) ?></p>
                </a>
                <?php endforeach ?>
            </div>
        </section>
    </div>
<?= $this->endSection() ?>