<?= $this->extend("layout/template") ?>
<?= $this->section("content") ?>
    <section class="containerSurah">
        <p style="font-size: x-large; display:flex; justify-content: center;">Doa Sebelum dan Sesudah Masuk Kamar Mandi</p>
        <div style="display: flex; justify-content: center; margin-top: 5vh">
            <img src="<?= base_url('images/Home-Image.png'); ?>" alt="" style="width: 250px;">
        </div>
        <div style="display: flex; width: 100%; justify-content: space-between; gap:3vw;">
            <div style="width: 50%; margin-top: 5vh;">
                <h2 style="display: flex; justify-content: center;">Keutamaan Doa Sebelum Masuk Kamar Mandi</h2>
                <p style="text-align: justify; font-size:larger;"><?= $keutamaan['keutamaan'] ?></p>
                <h2 style="display: flex; justify-content: center; margin-top: 5vh;">Keutamaan Doa Sesudah Masuk Kamar Mandi</h2>
                <p style="text-align: justify; font-size:larger;"><?= $keutamaan['keutamaan_sesudah'] ?></p>
            </div>
            <div style="width: 50%;">
                <?php foreach ($isi as $i) : ?>
                    <p style="font-size: larger; display: flex; justify-content:end; margin-top: 5vh; text-align: end; opacity:calc(0.7);"><?= esc($i['isi_arab']) ?></p>
                    <p style="font-size: larger; display: flex; justify-content:end; text-align: end"><?= esc($i['isi_latin']) ?></p>
                    <p style="font-size: larger; opacity:calc(0.5); display: flex; justify-content:end; text-align: end"><?= esc($i['isi_indonesia']) ?></p>
                <?php endforeach ?>
            </div>
        </div>
    </section>
<?= $this->endSection() ?>