<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Paytone+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css'); ?>">
</head>
<body>
    <?= $this ->include('layout/navbar.php') ?>
    <?= $this ->renderSection('content'); ?>

    <script src="<?= base_url('js/script.js'); ?>"></script>
</body>
</html>