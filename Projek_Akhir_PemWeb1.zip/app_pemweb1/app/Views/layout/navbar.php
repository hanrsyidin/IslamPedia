<nav class="NavBar">
    <div class="kotakTerluar">
        <div class="kontenNavBar">
            <p style="color: #FFFBD7; font-size: xx-large">IslamPedia</p>
            <ul class="menus">
                <li><a href="/" class="menusHover">Home</a></li>
                <li><a href="/pages/surah" class="menusHover">Surah</a></li>
                <li><a href="/pages/sunnah" class="menusHover">Sunnah</a></li>
                <li><a href="/pages/rukun" class="menusHover">Rukun</a></li>
            </ul>
        </div>
    </div>
</nav>