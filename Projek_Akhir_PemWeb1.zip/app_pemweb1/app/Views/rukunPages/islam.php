<?= $this->extend("layout/template") ?>
<?= $this->section("content") ?>
    <section class="containerSurah">
        <p style="font-size: x-large; display:flex; justify-content: center;">Rukun Islam</p>
        <div style="display: flex; justify-content: center; margin-top: 5vh">
            <img src="<?= base_url('images/Home-Image.png'); ?>" alt="" style="width: 250px;">
        </div>
        <div style="display: flex; justify-content: space-between; gap:3vw;">
            <div>
                <?php foreach ($isi as $i) : ?>
                    <p style="font-size: larger; display: flex; margin-top: 5vh; text-align: end;"><?= $i['isi_arab'] ?></p>
                    <p style="font-size: larger; display: flex; opacity:calc(0.5);"><?= $i['isi_latin'] ?></p>
                <?php endforeach ?>
            </div>
        </div>
    </section>
<?= $this->endSection() ?>