// script animasi ketik IslamPedia | Home Page
const text = "IslamPedia"; // Teks yang akan diketik
const typingText = document.getElementById("typing-text");
let index = 0;
let isDeleting = false; // Status mengetik atau menghapus

function typeEffect() {
    if (!isDeleting && index <= text.length) {
        typingText.textContent = text.substring(0, index); // Tambahkan huruf
        index++;
        setTimeout(typeEffect, 150); // Interval mengetik
    } else if (isDeleting && index >= 0) {
        typingText.textContent = text.substring(0, index); // Hapus huruf
        index--;
        setTimeout(typeEffect, 150); // Interval menghapus
    } else {
        isDeleting = !isDeleting; // Ubah status
        setTimeout(typeEffect, 2000); // Jeda sebelum mengulang
    }
}
// endScript animasi ketik IslamPedia



// script animasi enterance | Home Page
// Mulai animasi
window.onload = typeEffect;

// Fungsi untuk menambahkan class animasi saat elemen terlihat di layar

function animateOnScroll() {
    const animatedElements = document.querySelectorAll('.animated-left, .animated-right');
    animatedElements.forEach((element) => {
        const rect = element.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom >= 0) {
            element.style.animationPlayState = "running";
            element.style.transform = "none"; // Reset posisi transform
        }
    });
}

// Event listener untuk scroll
document.addEventListener('scroll', animateOnScroll);
// Panggil saat pertama kali halaman dimuat
animateOnScroll();
// endScript animasi enterance



// 