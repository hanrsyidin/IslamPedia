-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2024 at 03:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `info_surah`
--

-- --------------------------------------------------------

--
-- Table structure for table `judul_rukun`
--

CREATE TABLE `judul_rukun` (
  `id` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `baseURL` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `judul_rukun`
--

INSERT INTO `judul_rukun` (`id`, `judul`, `baseURL`) VALUES
(1, 'Rukun Islam', '/RukunPages/Islam'),
(2, 'Rukun Iman', '/RukunPages/Iman');

-- --------------------------------------------------------

--
-- Table structure for table `judul_sunnah`
--

CREATE TABLE `judul_sunnah` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `baseURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `judul_sunnah`
--

INSERT INTO `judul_sunnah` (`id`, `judul`, `baseURL`) VALUES
(1, 'Doa Sebelum dan Sesudah Makan', '/SunnahPages/makan'),
(2, 'Doa Sebelum Tidur dan Bangun Tidur', '/SunnahPages/tidur'),
(3, 'Doa Masuk dan Keluar Kamar Mandi', '/SunnahPages/kamar_mandi');

-- --------------------------------------------------------

--
-- Table structure for table `judul_surah`
--

CREATE TABLE `judul_surah` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `baseURL` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `judul_surah`
--

INSERT INTO `judul_surah` (`id`, `judul`, `baseURL`) VALUES
(1, '114. An-Nas (Mekah | 6 Ayat)', '/SurahPages/an_nas'),
(2, '113. Al-Falaq (Mekah | 5 Ayat)', '/SurahPages/al_falaq'),
(3, '112. Al-Ikhlas (Mekah | 4 Ayat)', '/SurahPages/al_ikhlas'),
(4, '111. Al-Lahab (Mekah | 5 Ayat)', '/SurahPages/al_lahab'),
(5, '110. An-Nasr (Madinah | 3 Ayat)', '/SurahPages/an_nasr');

-- --------------------------------------------------------

--
-- Table structure for table `keutamaan_sunnah`
--

CREATE TABLE `keutamaan_sunnah` (
  `id` int(11) NOT NULL,
  `nama_sunnah` varchar(255) NOT NULL,
  `keutamaan` text DEFAULT NULL,
  `keutamaan_sesudah` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keutamaan_sunnah`
--

INSERT INTO `keutamaan_sunnah` (`id`, `nama_sunnah`, `keutamaan`, `keutamaan_sesudah`) VALUES
(1, 'makan', '\r\n1. Memulai dengan Nama Allah, Membaca Bismillah sebelum makan adalah bentuk mengingat Allah dan menunjukkan rasa syukur atas nikmat yang diberikan. Hal ini membuat makanan yang kita makan menjadi lebih berkah.\r\n<br><br>\r\n2. Mencegah Gangguan Setan, Rasulullah SAW bersabda bahwa setan tidak dapat ikut makan bersama seseorang yang membaca nama Allah sebelum makan.\r\n\"Apabila seseorang masuk rumahnya dan menyebut nama Allah saat memasukinya serta saat makannya, maka setan berkata, \'Tidak ada tempat menginap dan tidak ada makan malam untuk kalian.\'\" (HR. Muslim).\r\n<br><br>\r\n3. Melatih Kesadaran Diri, Doa sebelum makan membuat kita lebih sadar bahwa makanan yang kita nikmati adalah karunia dari Allah, sehingga menjauhkan diri dari sifat lalai dan serakah.', '\r\n1. Mengungkapkan Syukur kepada Allah, Mengucapkan Alhamdulillah setelah makan menunjukkan rasa syukur atas rezeki yang diberikan Allah. Ini adalah akhlak yang dicintai oleh-Nya.\r\n<br><br>\r\n2. Menambah Nikmat, Allah SWT berjanji akan menambah nikmat bagi hamba-Nya yang bersyukur. Dengan bersyukur setelah makan, kita berharap rezeki kita akan terus diberkahi.<br>\r\n\"Jika kalian bersyukur, pasti Aku akan menambah nikmat kepada kalian.\" (QS. Ibrahim: 7).\r\n<br><br>\r\n3. Meningkatkan Keimanan, Doa ini mengingatkan kita bahwa Allah-lah yang menciptakan, memberi rezeki, dan memberi kekuatan untuk menikmati makanan tersebut, sehingga memperkuat hubungan kita dengan-Nya.\r\n<br><br>\r\n4. Mengajarkan Akhlak yang Baik, Membiasakan diri untuk berdoa setelah makan adalah cara Rasulullah SAW mendidik umatnya agar senantiasa mengingat Allah dalam setiap keadaan, baik saat kenyang maupun lapar.'),
(2, 'tidur', '\r\n 1. Menghadirkan Rasa Tawakkal kepada Allah, Dengan membaca doa, kita menyerahkan diri sepenuhnya kepada Allah SWT, mengakui bahwa hidup dan mati kita berada di tangan-Nya.<br>\r\n\"Bismika Allahumma amuutu wa ahyaa\" (Dengan nama-Mu ya Allah, aku hidup dan aku mati).\r\n<br><br>\r\n2. Perlindungan dari Gangguan Setan, Doa sebelum tidur adalah bentuk perlindungan dari gangguan setan selama kita tidur. Rasulullah SAW juga mengajarkan membaca ayat-ayat tertentu seperti Ayat Kursi untuk menambah perlindungan.\r\n<br><br>\r\n3. Meningkatkan Kesadaran Spiritual, Mengingat Allah sebelum tidur membantu menjaga hati tetap tenang dan mendekatkan diri kepada-Nya, sehingga tidur menjadi ibadah.\r\n<br><br>\r\n4. Melatih Kedisiplinan dalam Beribadah, Membiasakan doa sebelum tidur melatih diri untuk selalu mengingat Allah dalam setiap aktivitas, bahkan saat akan beristirahat.\r\n<br><br>\r\n5. Memulai Tidur dengan Keberkahan, Dengan doa, tidur kita menjadi lebih tenang dan diberkahi, sehingga tubuh kita dapat beristirahat dengan optimal.\r\n', '\r\n 1. Mengungkapkan Syukur atas Hidup Baru, Doa setelah bangun tidur adalah wujud rasa syukur atas kesempatan hidup yang Allah berikan kembali.<br>\r\n\"Alhamdulillahilladzi ahyaana ba’da maa amaatana wa ilaihin nushuur\" (Segala puji bagi Allah yang telah menghidupkan kami setelah mematikan kami, dan kepada-Nya kami kembali).\r\n<br><br>\r\n2. Mengawali Hari dengan Mengingat Allah, Membaca doa setelah bangun tidur memulai hari dengan keberkahan, membantu kita menjaga hubungan dengan Allah SWT.\r\n<br><br>\r\n3. Melatih Rasa Ketergantungan pada Allah, Doa ini mengingatkan kita bahwa Allah adalah sumber kehidupan, sehingga menumbuhkan ketawakkalan kepada-Nya dalam menjalani aktivitas sehari-hari.\r\n<br><br>\r\n4. Memberikan Energi Positif, Dengan doa, kita mengisi hati dengan energi positif dan mempersiapkan diri menghadapi hari dengan semangat dan rasa syukur.\r\n<br><br>\r\n5. Meningkatkan Kesadaran Ibadah, Membiasakan doa setelah bangun tidur melatih diri untuk selalu memulai hari dengan ibadah, menjadikan setiap aktivitas kita bernilai di sisi Allah SWT.'),
(3, 'kamar_mandi', '\r\n1. Perlindungan dari Gangguan Setan, Rasulullah SAW mengajarkan doa ini untuk memohon perlindungan dari gangguan setan yang suka berada di tempat-tempat kotor seperti kamar mandi.<br>\r\n\"Sesungguhnya tempat buang hajat itu dihuni setan.\" (HR. Abu Dawud).\r\n<br><br>\r\n2. Menjaga Adab dan Kesucian, Membaca doa sebelum masuk kamar mandi menunjukkan kepatuhan pada adab Islam dalam menjaga kesucian hati dan tubuh, terutama di tempat yang rentan dengan kotoran.\r\n<br><br>\r\n3. Menghadirkan Kesadaran Akan Allah, Dengan doa ini, kita mengingat bahwa Allah senantiasa melindungi hamba-Nya, termasuk dalam aktivitas sehari-hari seperti buang hajat.\r\n<br><br>\r\n4. Mendapatkan Berkah dalam Rutinitas Sehari-hari, Memulai aktivitas dengan doa mendatangkan keberkahan dan membantu menjaga kesadaran spiritual.\r\n<br><br>\r\n5. Mengikuti Sunnah Rasulullah SAW, Membaca doa ini adalah bentuk ittiba’ (mengikuti) sunnah Nabi, yang membawa pahala dan kedekatan dengan Allah SWT.', '\r\n1. Memohon Ampunan atas Kelalaian, Doa ini merupakan bentuk introspeksi diri karena selama di kamar mandi, kita tidak diperkenankan untuk berdzikir atau menyebut nama Allah.\r\n<br><br>\r\n2. Meningkatkan Kesadaran Akan Kebutuhan kepada Allah, Dengan memohon ampun, kita mengakui bahwa segala sesuatu, termasuk kesucian dan kesehatan, adalah nikmat dari Allah SWT.\r\n<br><br>\r\n3. Menutup Aktivitas dengan Kebaikan, Membaca doa setelah keluar kamar mandi menunjukkan sikap seorang Muslim yang selalu berupaya mengakhiri setiap aktivitas dengan mengingat Allah.\r\n<br><br>\r\n4. Mendapatkan Keberkahan, Doa ini menambah keberkahan dalam keseharian kita karena mengingatkan untuk selalu bertawakal kepada Allah dalam segala keadaan.\r\n<br><br>\r\n5. Mencontoh Sunnah Nabi Muhammad SAW, Membaca doa ini adalah sunnah Nabi yang membawa pahala dan menjadi bukti kecintaan kita kepada Rasulullah SAW.');

-- --------------------------------------------------------

--
-- Table structure for table `kisah_surah`
--

CREATE TABLE `kisah_surah` (
  `id` int(11) NOT NULL,
  `nama_surah` varchar(255) NOT NULL,
  `isi_kisah` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kisah_surah`
--

INSERT INTO `kisah_surah` (`id`, `nama_surah`, `isi_kisah`) VALUES
(1, 'Al_ikhlas', 'Surah Al-Ikhlas diturunkan di Makkah sebagai tanggapan atas pertanyaan kaum Quraisy yang meminta Nabi Muhammad SAW menjelaskan tentang Allah SWT. Sebagian dari mereka bertanya apakah Allah memiliki keturunan atau apakah Dia dilahirkan, sebagaimana kepercayaan politeistik yang mereka anut. Surah ini secara tegas menjelaskan keesaan dan sifat-sifat Allah yang berbeda dari makhluk-Nya.\r\n<br><br>\r\n    Isi kandungan surah ini menekankan bahwa:\r\n<br><br>\r\n    1. Allah adalah Esa (Ahad), yang tidak memiliki sekutu, bandingan, atau tandingan.<br>\r\n    2. Allah adalah tempat bergantung segala makhluk (As-Samad), yang mencukupi segala kebutuhan tanpa bergantung kepada siapa pun.<br>\r\n    3. Allah tidak beranak dan tidak diperanakkan, menegaskan bahwa Dia tidak memiliki hubungan biologis atau keturunan seperti makhluk hidup.<br>\r\n    4. Tidak ada satu pun yang setara atau sebanding dengan-Nya.\r\n<br><br>\r\n    Pesan dalam surah ini memperkuat tauhid (keyakinan kepada keesaan Allah) dan membantah konsep kemusyrikan. Surah ini juga memiliki keutamaan besar, seperti disebutkan dalam beberapa hadits bahwa membacanya setara dengan membaca sepertiga Al-Qur\'an, karena ia mencakup salah satu dari tiga tema utama Al-Qur\'an, yaitu sifat-sifat Allah​.\r\n<br><br>\r\n    Untuk penjelasan lebih rinci, Anda dapat membaca sumber-sumber seperti Tafsir Ibnu Katsir atau referensi lain yang mendalam tentang Surah Al-Ikhlas.'),
(2, 'an_nas', 'Surah An-Nas diturunkan di Makkah sebagai salah satu dari dua surah perlindungan (Al-Mu\'awwidzatain) bersama Surah Al-Falaq. Menurut beberapa riwayat, surah ini turun ketika Nabi Muhammad SAW terkena sihir yang dilakukan oleh Labid bin Al-A\'sham, seorang Yahudi. Allah menurunkan Surah Al-Falaq dan An-Nas untuk mengajarkan cara memohon perlindungan dari gangguan sihir, bisikan setan, dan kejahatan makhluk halus yang tersembunyi.\r\n<br><br>\r\nSurah ini memuat tiga sifat Allah: Rabb (Pemelihara), Malik (Raja), dan Ilah (Sembahan) manusia. Ketiganya menjadi landasan untuk memohon perlindungan secara total kepada Allah dari godaan dan kejahatan setan, baik yang tampak maupun tersembunyi.'),
(3, 'al_falaq', 'Surah Al-Falaq diturunkan sebagai bagian dari dua surat perlindungan, yaitu Al-Mu’awwidzatain (Surah Al-Falaq dan An-Nas). Kisah turunnya surah ini berhubungan dengan kejadian Rasulullah SAW yang disihir oleh Lubaid bin Al-A’sham, seorang dari Bani Zuraiq, sekutu Yahudi.\r\n<br><br>\r\nSihir itu berupa rambut rontok yang diikat dengan sebelas buhul dan disimpan di dalam kulit mayang kurma, kemudian diletakkan di dasar sumur Dzarwan. Nabi SAW mengalami dampak dari sihir tersebut, seperti merasa melakukan sesuatu yang sebenarnya tidak dilakukan. Malaikat Jibril turun membawa wahyu berupa dua surat ini, yang setiap ayatnya membantu mematahkan satu buhul dari sihir tersebut. Ketika seluruh buhul terbuka, Nabi SAW pun terbebas dari pengaruh sihir.\r\n<br><br>\r\nSurah ini juga menjadi pelindung dari berbagai kejahatan, termasuk kejahatan malam, sihir, dan iri hati. Ayat-ayatnya biasa digunakan dalam doa perlindungan oleh Rasulullah, terutama sebelum tidur.'),
(4, 'al_lahab', 'Kisah turunnya Surah Al-Lahab (Al-Masad) berhubungan langsung dengan penolakan dan hinaan Abu Lahab terhadap dakwah Nabi Muhammad SAW. Ketika Rasulullah SAW menerima perintah Allah untuk memberi peringatan kepada kaum terdekatnya, beliau mengumpulkan suku Quraisy di Bukit Shafa. Dalam pertemuan tersebut, Rasulullah SAW memberikan peringatan bahwa azab Allah akan datang kepada mereka jika mereka tidak beriman.\r\n<br><br>\r\nSetelah mendengar peringatan ini, Abu Lahab dengan angkuhnya berkata, “Celaka kamu, apakah hanya untuk ini engkau mengumpulkan kami?” Ucapannya tersebut mencerminkan sikap keras kepala dan permusuhannya terhadap dakwah Rasulullah. Sebagai respons terhadap perilaku ini, Allah menurunkan Surah Al-Lahab, yang mengecam Abu Lahab dan istrinya, yang juga terlibat aktif dalam mengganggu Rasulullah SAW dengan menebarkan duri di jalan yang akan dilewati beliau.\r\n<br><br>\r\nSurah ini menjadi bukti nyata tentang ancaman terhadap penentang keras dakwah Islam dan juga peringatan bahwa sikap permusuhan terhadap kebenaran akan mendapatkan balasan dari Allah SWT.'),
(5, 'an_nasr', 'Surah An-Nasr (QS 110) memiliki kisah menarik yang berkaitan dengan latar belakang turunnya dan maknanya. Surah ini turun di Madinah dan menjadi salah satu surah terakhir yang diwahyukan kepada Rasulullah SAW.\r\n<br><br>\r\nAsbabun Nuzul: Surah ini berkaitan dengan kemenangan umat Islam dalam peristiwa Fathul Makkah. Setelah pembebasan Makkah, banyak suku Arab yang sebelumnya ragu mulai masuk Islam secara berbondong-bondong. Surah ini menandai puncak dakwah Rasulullah SAW, sekaligus menjadi isyarat tentang dekatnya akhir hayat beliau. Menurut tafsir, Allah memerintahkan Rasulullah SAW untuk memperbanyak tasbih, tahmid, dan istighfar sebagai bentuk syukur atas pertolongan dan kemenangan yang diberikan-Nya.\r\n<br><br>\r\nMakna Surah An-Nasr:\r\n<br><br>\r\nAyat 1: Menyampaikan bahwa pertolongan Allah dan kemenangan yang dimaksud adalah pembebasan Makkah dari syirik dan kekafiran.<br>\r\nAyat 2: Menggambarkan banyaknya orang yang masuk Islam setelah pembebasan tersebut.<br>\r\nAyat 3: Allah memerintahkan Nabi Muhammad SAW untuk memuji-Nya dan memohon ampunan, mengajarkan umat agar selalu bersyukur dan beristighfar setelah mencapai keberhasilan.<br>\r\n<br>\r\nUmar bin Khattab dan sahabat lain yang berdiskusi dengan Ibnu Abbas menyadari bahwa surah ini juga menjadi tanda mendekatnya ajal Rasulullah SAW. Setelah peristiwa ini, Rasulullah pun semakin mempersiapkan diri untuk menghadapi pertemuan dengan Allah.\r\n<br><br>\r\nSemoga informasi ini bermanfaat untuk memahami makna dan kisah di balik turunnya Surah An-Nasr.');

-- --------------------------------------------------------

--
-- Table structure for table `rukun_iman`
--

CREATE TABLE `rukun_iman` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rukun_iman`
--

INSERT INTO `rukun_iman` (`id`, `isi_arab`, `isi_latin`) VALUES
(1, 'Iman Kepada Allah', 'Meyakini dengan sepenuh hati keberadaan Allah, keesaan-Nya, sifat-sifat-Nya, dan bahwa hanya Allah yang berhak disembah.'),
(2, 'Iman Kepada Malaikai', 'Meyakini adanya malaikat yang diciptakan oleh Allah dari cahaya dan menjalankan tugas tertentu sesuai perintah Allah.'),
(3, 'Iman Kepada Kitab-kitab Allah', 'Meyakini bahwa Allah telah menurunkan kitab-kitab suci (Taurat, Zabur, Injil, dan Al-Quran) sebagai petunjuk bagi manusia.'),
(4, 'Iman Kepada Rasul-rasul Allah', 'Meyakini bahwa Allah mengutus para nabi dan rasul untuk menyampaikan wahyu-Nya kepada umat manusia, dengan Nabi Muhammad SAW sebagai nabi terakhir.'),
(5, 'Iman Kepada Hari Akhir', 'Meyakini bahwa kehidupan dunia ini akan berakhir dan akan ada kehidupan setelah mati (akhirat) yang mencakup kebangkitan, hisab, surga, dan neraka.'),
(6, 'Iman Kepada Qada dan Qadar', 'Meyakini bahwa segala sesuatu yang terjadi di alam semesta ini telah ditetapkan oleh Allah, baik itu takdir baik maupun buruk.');

-- --------------------------------------------------------

--
-- Table structure for table `rukun_islam`
--

CREATE TABLE `rukun_islam` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rukun_islam`
--

INSERT INTO `rukun_islam` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'Syahadat', 'Mengucapkan dan meyakini kalimat syahadat, yaitu:<br>\r\n\"Ashhadu an laa ilaaha illallah wa ashhadu anna Muhammadar Rasulullah\" (Aku bersaksi bahwa tiada Tuhan selain Allah, dan aku bersaksi bahwa Muhammad adalah utusan Allah).', ''),
(2, 'Sholat 5 waktu', 'Mendirikan shalat wajib lima waktu setiap hari.', ''),
(3, 'Puasa di bulan suci Ramadhan', ' Menahan diri dari makan, minum, dan segala hal yang membatalkan puasa dari terbit fajar hingga terbenam matahari selama bulan Ramadan.', ''),
(4, 'Zakat', 'Mengeluarkan sebagian harta kepada mereka yang berhak menerimanya sebagai bentuk penyucian diri dan harta.', ''),
(5, 'Haji ke Baitullah', 'Melaksanakan ibadah haji ke Mekah bagi yang mampu secara fisik, mental, dan finansial setidaknya sekali seumur hidup.', '');

-- --------------------------------------------------------

--
-- Table structure for table `sunnah_kamar_mandi`
--

CREATE TABLE `sunnah_kamar_mandi` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sunnah_kamar_mandi`
--

INSERT INTO `sunnah_kamar_mandi` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'Masuk kamar mandi:', 'Allahumma inni a’udzubika minal khubutsi wal khabaa\'ith.', '(Ya Allah, aku berlindung kepada-Mu dari gangguan setan laki-laki dan setan perempuan).'),
(2, 'Keluar kamar mandi:', 'Ghufranaka.', '(Aku memohon ampun kepada-Mu).');

-- --------------------------------------------------------

--
-- Table structure for table `sunnah_makan`
--

CREATE TABLE `sunnah_makan` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sunnah_makan`
--

INSERT INTO `sunnah_makan` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'Sebelum makan:', 'Bismillah', '(Dengan nama Allah).'),
(2, 'Sesudah makan:', 'Alhamdulillahilladzi ath’amana wasaqana waja’alana muslimin.', '(Segala puji bagi Allah yang telah memberi kami makan, minum, dan menjadikan kami sebagai orang-orang Muslim).');

-- --------------------------------------------------------

--
-- Table structure for table `sunnah_tidur`
--

CREATE TABLE `sunnah_tidur` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sunnah_tidur`
--

INSERT INTO `sunnah_tidur` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'Sebelum tidur:', 'Bismika Allahumma amuutu wa ahyaa.', '(Dengan nama-Mu ya Allah, aku hidup dan aku mati).'),
(2, 'Bangun tidur:', 'Alhamdulillahilladzi ahyaana ba’da maa amaatana wa ilaihin nushuur.', '(Segala puji bagi Allah yang telah menghidupkan kami kembali setelah sebelumnya mematikan kami, dan kepada-Nya kami kembali).');

-- --------------------------------------------------------

--
-- Table structure for table `surah_al_falaq`
--

CREATE TABLE `surah_al_falaq` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `surah_al_falaq`
--

INSERT INTO `surah_al_falaq` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', 'Bismillahirrahmanirrahim', 'Dengan nama Allah Yang Maha Pengasih lagi Maha Penyayang'),
(2, 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ [1]', 'Qul a\'udzu birabbil-falaq', 'Katakanlah, \"Aku berlindung kepada Tuhan yang menguasai waktu subuh,\"'),
(3, 'مِن شَرِّ مَا خَلَقَ [2]', 'Min sharri ma khalaq', 'dari kejahatan makhluk yang Dia ciptakan,'),
(4, 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ [3]', 'Wa min sharri ghasiqin idza waqab', 'dan dari kejahatan malam apabila telah gelap gulita,'),
(5, 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ [4]', 'Wa min sharrin-naffathati fil \'uqad', 'dan dari kejahatan para penyihir yang meniup pada buhul-buhul (talinya),'),
(6, 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ [5]', 'Wa min sharri hasidin idza hasad', 'dan dari kejahatan orang yang dengki apabila ia dengki.');

-- --------------------------------------------------------

--
-- Table structure for table `surah_al_ikhlas`
--

CREATE TABLE `surah_al_ikhlas` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `surah_al_ikhlas`
--

INSERT INTO `surah_al_ikhlas` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', 'Bismillahirrahmanirrahim', 'Dengan nama Allah Yang Maha Pengasih, Maha Penyayang.'),
(2, '[1] قُلْ هُوَ اللَّهُ أَحَدٌ', 'Qul huwallahu ahad', 'Katakanlah (Muhammad): \"Dialah Allah, Yang Maha Esa.\"'),
(3, '[2] اللَّهُ الصَّمَدُ', 'Allahus-samad', 'Allah tempat meminta segala sesuatu.'),
(4, '[3] لَمْ يَلِدْ وَلَمْ يُولَدْ', 'Lam yalid wa lam yulad', 'Dia tidak beranak dan tidak pula diperanakkan.'),
(5, '[4] وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ', 'Walam yakul-lahu kufuwan ahad', 'Dan tidak ada sesuatu yang setara dengan Dia.');

-- --------------------------------------------------------

--
-- Table structure for table `surah_an_nas`
--

CREATE TABLE `surah_an_nas` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `surah_an_nas`
--

INSERT INTO `surah_an_nas` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', 'Bismillahirrahmanirrahim', 'Dengan nama Allah Yang Maha Pengasih lagi Maha Penyayang'),
(2, 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ [1]', 'Qul a\'udzu birabbinnas', 'Katakanlah, \"Aku berlindung kepada Tuhan manusia,\"'),
(3, 'مَلِكِ النَّاسِ [2]', 'Malikin nas', 'Raja manusia,'),
(4, 'إِلَٰهِ النَّاسِ [3]', 'Ilahinnas', 'Sesembahan manusia,'),
(5, 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ [4]', 'Min sharil waswasi khannas', 'dari kejahatan bisikan syaitan yang tersembunyi,'),
(6, 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ [5]', 'Alladzi yuwaswisu fi sudurinnas', 'yang membisikkan dalam hati manusia,'),
(7, 'مِنَ الْجِنَّةِ وَالنَّاسِ [6]', 'Minal jinnati wal-nas', 'dari golongan jin dan manusia.');

-- --------------------------------------------------------

--
-- Table structure for table `surah_an_nasr`
--

CREATE TABLE `surah_an_nasr` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `surah_an_nasr`
--

INSERT INTO `surah_an_nasr` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', 'Bismillahirrahmanirrahim', 'Dengan nama Allah Yang Maha Pengasih lagi Maha Penyayang'),
(2, 'إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ [1]', 'Iza jaa-a nasrullahi wal-fath', 'Apabila telah datang pertolongan Allah dan kemenangan,'),
(3, 'وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا [2]', 'Wa ra-aitan-nasa yadkhuluna fi dinillahi afwaja', 'dan engkau melihat manusia berbondong-bondong masuk agama Allah,'),
(4, 'فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۚ إِنَّهُ كَانَ تَوَّابًا [3]', 'Fasabbih bihamdi rabbika wastaghfirh, innahu kana tawwaba', 'maka bertasbihlah dengan memuji Tuhanmu dan mohonlah ampun kepada-Nya. Sungguh, Dia Maha Penerima tobat.');

-- --------------------------------------------------------

--
-- Table structure for table `surah_lahab`
--

CREATE TABLE `surah_lahab` (
  `id` int(11) NOT NULL,
  `isi_arab` varchar(255) NOT NULL,
  `isi_latin` varchar(255) NOT NULL,
  `isi_indonesia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `surah_lahab`
--

INSERT INTO `surah_lahab` (`id`, `isi_arab`, `isi_latin`, `isi_indonesia`) VALUES
(1, 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', 'Bismillahirrahmanirrahim', 'Dengan nama Allah Yang Maha Pengasih lagi Maha Penyayang'),
(2, 'تَبَّتْ يَدَا أَبِي لَهَبٍ وَتَبَّ [1]', 'Tabbat yada abi Lahabin wa tabb', 'Binasalah kedua tangan Abu Lahab, dan benar-benar binasa dia!'),
(3, 'مَا أَغْنَىٰ عَنْهُ مَالُهُ وَمَا كَسَبَ [2]', 'Ma aghna \'anhu maluhu wa ma kasab', 'Tidaklah berguna baginya harta bendanya dan apa yang dia usahakan.'),
(4, 'سَيَصْلَىٰ نَارًا ذَاتَ لَهَبٍ [3]', 'Sayasla naran dzata lahab', 'Kelak dia akan masuk ke dalam api yang bergejolak (neraka).'),
(5, 'وَٱمْرَأَتُهُۥ حَمَّالَةَ ٱلْحَطَبِ [4]', 'Wamra\'atuhu hammalat al-hatab', 'Dan (begitu pula) istrinya, pembawa kayu bakar (penyebar fitnah)'),
(6, 'فِى جِيدِهَا حَبْلٌ مِّن مَّسَدٍۭ [5]', 'Fi jidiha hablun min masad', 'Di lehernya ada tali dari sabut yang dipintal.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `judul_rukun`
--
ALTER TABLE `judul_rukun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `judul_sunnah`
--
ALTER TABLE `judul_sunnah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `judul_surah`
--
ALTER TABLE `judul_surah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keutamaan_sunnah`
--
ALTER TABLE `keutamaan_sunnah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kisah_surah`
--
ALTER TABLE `kisah_surah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rukun_iman`
--
ALTER TABLE `rukun_iman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rukun_islam`
--
ALTER TABLE `rukun_islam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sunnah_kamar_mandi`
--
ALTER TABLE `sunnah_kamar_mandi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sunnah_makan`
--
ALTER TABLE `sunnah_makan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sunnah_tidur`
--
ALTER TABLE `sunnah_tidur`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surah_al_falaq`
--
ALTER TABLE `surah_al_falaq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surah_al_ikhlas`
--
ALTER TABLE `surah_al_ikhlas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surah_an_nas`
--
ALTER TABLE `surah_an_nas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surah_an_nasr`
--
ALTER TABLE `surah_an_nasr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surah_lahab`
--
ALTER TABLE `surah_lahab`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `judul_rukun`
--
ALTER TABLE `judul_rukun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `judul_sunnah`
--
ALTER TABLE `judul_sunnah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `judul_surah`
--
ALTER TABLE `judul_surah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `keutamaan_sunnah`
--
ALTER TABLE `keutamaan_sunnah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kisah_surah`
--
ALTER TABLE `kisah_surah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rukun_iman`
--
ALTER TABLE `rukun_iman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rukun_islam`
--
ALTER TABLE `rukun_islam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sunnah_kamar_mandi`
--
ALTER TABLE `sunnah_kamar_mandi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sunnah_makan`
--
ALTER TABLE `sunnah_makan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sunnah_tidur`
--
ALTER TABLE `sunnah_tidur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `surah_al_falaq`
--
ALTER TABLE `surah_al_falaq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `surah_al_ikhlas`
--
ALTER TABLE `surah_al_ikhlas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `surah_an_nas`
--
ALTER TABLE `surah_an_nas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `surah_an_nasr`
--
ALTER TABLE `surah_an_nasr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `surah_lahab`
--
ALTER TABLE `surah_lahab`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
